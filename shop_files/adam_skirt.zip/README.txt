Adam Skirt - A Custom Lower Body Mod for Comedy World created by Lane's GA World

This mod is ok to install for use on Wrapper: Offline and other LVM clones that support mods. If you are a developer for a LVM clone, please ask me before including it in your LVM.

=====HOW TO INSTALL=====

1. Locate the "family" folder in the "cc_store" folder of Wrapper. The directory should be "server\store\3a981f5cb2739137\cc_store\family"

2. Open up the "lower_body" folder.

3. Extract the "adam_0xx" to the "lower_body" folder and rename the "0xx" to any number. PLEASE MAKE SURE TO KEEP THE "adam_" PART!

4. Once done, open up "cc_theme.xml" and scroll down until you find "<component type="upper_body" id="adam_001" path="adam_001" name="adam_001" thumb="thumbnail.swf">".

5. Above the previously mentioned line, press Enter and copy the following lines of text, then paste it in the new line you just created.
        <component type="lower_body" id="adam_0xx" path="adam_0xx" name="adam_0xx" thumb="thumbnail.swf" display_order="180" money="0" sharing="0" enable="Y">
            <state id="dance" filename="dance.swf"/>
            <state id="default" filename="default.swf"/>
            <state id="excited" filename="excited.swf"/>
            <state id="fearful" filename="fearful.swf"/>
            <state id="kneel_down" filename="kneel_down.swf"/>
            <state id="laugh" filename="laugh.swf"/>
            <state id="run" filename="run.swf"/>
            <state id="sit" filename="sit.swf"/>
            <state id="walk" filename="walk.swf"/>
        </component>
(make sure to rename 0xx to whatever you named the 0xx folder earlier!)

6. Save the XML, and you should be done!

==========

If you have any issues, please contact Lane#3658 on Discord.
Enjoy the mod!