HOW TO INSTALL:
------------------------
Video Tutorial:
------------------------
Text Tutorial:

1. Go to this directory: "\wrapper-offline\server\store\3a981f5cb2739137\cc_store\family\facedecoration"
2. Drag and drop the 099 folder into that directory.
3. Go to this directory: "\wrapper-offline\server\store\3a981f5cb2739137\cc_store\family\"
4. Right click "cc_theme.xml" and click "Open With" then click "NotePad" (Or Notepad++ if you have it)
5. Make sure Word Wrap is turned off. (To turn it off go to  Format -> Word Wrap and make sure it is off.
6. Scroll down to the bottom until you see this wall of text 

<component type="facedecoration" id="077" path="077" name="077" thumb="thumbnail.swf" money="0" sharing="0" enable="Y">
		<state id="default" filename="default.swf"/>
</component>

7. Copy it and paste it under the end of the wall of text you copied.
8. Change id="077" to id="099"
9. Change path="077" to id="099"
10. Change name="077" to name="099"
11. Save it and you're done! Enjoy your Among Us mask!


